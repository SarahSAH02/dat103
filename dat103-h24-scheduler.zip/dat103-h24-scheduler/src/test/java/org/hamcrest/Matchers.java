package org.hamcrest;

public class Matchers {

}
