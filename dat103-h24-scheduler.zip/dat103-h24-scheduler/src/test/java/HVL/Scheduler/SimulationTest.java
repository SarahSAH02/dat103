package HVL.Scheduler;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SimulationTest {

    Map<Integer, List<Task>> arrivals;
    Simulation simulation;

    @BeforeEach
    public void setUp() {
        simulation = new Simulation();
        arrivals = Map.ofEntries(
                Map.entry(0, List.of(
                        simulation.makeTask(1),  
                        simulation.makeTask(5),
                        simulation.makeTask(3))),
                Map.entry(4, List.of(
                        simulation.makeTask(2),
                        simulation.makeTask(4),
                        simulation.makeTask(6))),
                Map.entry(14, List.of(
                        simulation.makeTask(5),
                        simulation.makeTask(2))),
                Map.entry(16, List.of(
                        simulation.makeTask(1),
                        simulation.makeTask(4))));

        simulation.setArrivals(arrivals);
    }

    @Test
    public void testRR() {
        // Time quantum for RR is 4 units
        var rrScheduler = new RRScheduler(simulation.getClock(), 4);
        simulation.setScheduler(rrScheduler);

        var steps = Stream.generate(() -> {
            simulation.step();
            var state = "T=%d %s".formatted(simulation.time(), rrScheduler.view());
            simulation.clocktick();
            return state;
        }).limit(34).collect(Collectors.toList());

        // Verify the expected output for each quantum of time
        assertThat(steps, contains(
            "T=0 Scheduled: T1 Ready: T2, T3",
            "T=1 Running: T1",
            "T=2 Running: T1",
            "T=3 Running: T1",
            "T=4 Running: T1", // T1 completes
            "T=5 Scheduled: T2 Ready: T3",
            "T=6 Running: T2",
            "T=7 Running: T2",
            "T=8 Running: T2",
            "T=9 Running: T2", // T2 partially done
            "T=10 Scheduled: T3 Ready: T2",
            "T=11 Running: T3",
            "T=12 Running: T3",
            "T=13 Running: T3", // T3 completes
            "T=14 Scheduled: T4 Ready: T2, T6",
            "T=15 Running: T4",
            "T=16 Running: T4", // T4 completes
            "T=17 Scheduled: T5 Ready: T2, T6",
            "T=18 Running: T5",
            "T=19 Running: T5",
            "T=20 Running: T5", // T5 completes
            "T=21 Scheduled: T6 Ready: T2",
            "T=22 Running: T6",
            "T=23 Running: T6",
            "T=24 Running: T6",
            "T=25 Running: T6", // T6 completes
            "T=26 Scheduled: T2",
            "T=27 Running: T2",
            "T=28 Running: T2",
            "T=29 Running: T2", // T2 completes
            "T=30 Scheduled: T7 Ready: T8",
            "T=31 Running: T7",
            "T=32 Running: T7", // T7 partially done
            "T=33 Running: T7"  // T7 completes
        ));
    }

    @Test
    public void testNSJF() {
        // Create the NSJF Scheduler
        var nsjfScheduler = new NSJFScheduler();
        simulation.setScheduler(nsjfScheduler);

        var steps = Stream.generate(() -> {
            simulation.step();
            var state = "T=%d %s".formatted(simulation.time(), nsjfScheduler.view());
            simulation.clocktick();
            return state;
        }).limit(30).collect(Collectors.toList());

        // Verify the expected output for each time step
        assertThat(steps, contains(
            "T=0 Scheduled: T1 Ready: T3, T5",
            "T=1 Running: T1",
            "T=2 Running: T1",
            "T=3 Running: T1",
            "T=4 Running: T1",  // T1 completes (shortest task)
            "T=5 Scheduled: T3 Ready: T2, T4, T6",
            "T=6 Running: T3",
            "T=7 Running: T3",  // T3 completes (next shortest)
            "T=8 Scheduled: T5 Ready: T2, T4, T6",
            "T=9 Running: T5",
            "T=10 Running: T5",  // T5 completes
            "T=11 Scheduled: T2 Ready: T4, T6",
            "T=12 Running: T2",
            "T=13 Running: T2",
            "T=14 Running: T2",  // T2 completes
            "T=15 Scheduled: T4 Ready: T6",
            "T=16 Running: T4",
            "T=17 Running: T4",  // T4 completes
            "T=18 Scheduled: T6",
            "T=19 Running: T6",
            "T=20 Running: T6",  // T6 completes
            "T=21 Scheduled: T7 Ready: T8",
            "T=22 Running: T7",
            "T=23 Running: T7",  // T7 partially done
            "T=24 Running: T7",  // T7 completes
            "T=25 Scheduled: T8",
            "T=26 Running: T8",
            "T=27 Running: T8",  // T8 completes
            "T=28 Scheduled: <None>"
        ));
    }
}
