package HVL.Scheduler;

import java.util.*;

public class NSJFScheduler implements Scheduler {

    private Queue<Task> ready;
    private Task selected;

    NSJFScheduler() {
        this.ready = new ArrayDeque<>();
    }

    @Override
    public Optional<Integer> scheduled() {
        if(selected == null) return Optional.empty();
        return Optional.of(selected.getId());
    }

    @Override
    public List<Integer> ready() {
        return ready.stream().map(Task::getId).toList();
    }

    // Task 2: Complete the implementation of Non-preemptive Shortest Job First    
    @Override
    public void addTask(Task task) {
        ready.add(task);
    }

    @Override
    public void schedule() {
        if (selected == null) {
            // Select the task with the shortest burst time from the ready queue
            selected = ready.stream()
                    .min(Comparator.comparingInt(Task::getSize))
                    .orElse(null);  // Select the shortest task or none if the queue is empty
            
            if (selected == null) {
                return;  // No task available to schedule
            }

            // Remove the selected task from the ready queue and start it
            ready.remove(selected);
            selected.start();
        } else {
            // If the current task is done, stop it and select the next shortest task
            if (selected.isDone()) {
                selected.stop();
                selected = null;
                schedule();  // Select the next task
            }
        }
    }
}
