package HVL.Scheduler;

import java.util.*;
import java.util.function.IntSupplier;

public class RRScheduler implements Scheduler {

    private Queue<Task> ready;
    private final int limit;
    private Task selected;
    private IntSupplier time;
    private int timestamp;

    RRScheduler(IntSupplier time, int limit) {
        this.ready = new ArrayDeque<>();
        this.time = time;
        this.limit = limit;
        this.selected = null;
        this.timestamp = 0;
    }

    @Override
    public Optional<Integer> scheduled() {
        if(selected == null) return Optional.empty();
        return Optional.of(selected.getId());
    }

    public @Override List<Integer> ready() {
        return ready.stream().map((Task t)-> t.getId()).toList();
    }


    @Override
    public void addTask(Task task) {
        ready.add(task);
    }

    
              
   @Override
    public void schedule() {
        // If there's no currently selected task, attempt to select one from the ready queue
        if (selected == null) {
            selected = ready.poll();  // Get the next task in the queue
            if (selected == null) {
                return;  // No tasks available to schedule
            }
            selected.start();  // Mark the task as started
            timestamp = time.getAsInt();  // Record the current time
        } else {
            // If the currently selected task is done, stop it and schedule the next one
            if (selected.isDone()) {
                selected.stop();
                selected = null;  // Clear the selected task
                schedule();  // Try to schedule the next task
            } else {
                // Check if the time limit has been reached for the current task
                int now = time.getAsInt();
                if (now - timestamp >= limit) {
                    ready.add(selected);  // Re-add the task back to the ready queue
                    selected = null;  // Clear the selected task
                    schedule();  // Attempt to schedule the next task
                }
            }
        }
    }
}
